import express from "express";
import cors from "cors";
import sqlite3 from "sqlite3";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

const app = express();
app.use(express.json());
app.use(cors());

const PORT = 5050;
const ACCESS_SECRET = "ACCESS_SECRET_KEY";
const REFRESH_SECRET = "REFRESH_SECRET_KEY";

/* ---------------- DATABASE ---------------- */
const db = new sqlite3.Database("./mcp.db");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      password TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      token TEXT,
      user_id INTEGER
    )
  `);
});

/* ---------------- TOKEN HELPERS ---------------- */
const accessToken = (id) =>
  jwt.sign({ user_id: id }, ACCESS_SECRET, { expiresIn: "5m" });

const refreshToken = (id) =>
  jwt.sign({ user_id: id }, REFRESH_SECRET, { expiresIn: "7d" });

/* ---------------- AUTH ---------------- */
app.post("/auth/register", async (req, res) => {
  const { email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);

  db.run(
    `INSERT INTO users (email, password) VALUES (?, ?)`,
    [email, hash],
    function (err) {
      if (err) return res.status(400).json({ error: "User exists" });
      res.json({ message: "Registered", user_id: this.lastID });
    }
  );
});

app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;

  db.get(`SELECT * FROM users WHERE email = ?`, [email], async (_, user) => {
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const at = accessToken(user.id);
    const rt = refreshToken(user.id);

    db.run(`INSERT INTO refresh_tokens VALUES (?, ?)`, [rt, user.id]);

    res.json({
      user_id: user.id,
      access_token: at,
      refresh_token: rt
    });
  });
});

/* ---------------- POLICY ENGINE ---------------- */
function evaluate(message) {
  const text = message.toLowerCase().trim();

  if (/^(hi|hello|hey|how are you)$/.test(text)) {
    return {
      decision: "respond",
      response: "Hello 👋 How can I help you?"
    };
  }

  if (/(hack|illegal|bypass|exploit)/.test(text)) {
    return {
      decision: "restricted",
      restriction_message: "I cannot assist with that request."
    };
  }

  return {
    decision: "allow",
    filtered_prompt: message
  };
}

/* ---------------- MCP VALIDATE ---------------- */
app.post("/mcp/validate", (req, res) => {
  const { user_id, access_token, message } = req.body;

  try {
    const decoded = jwt.verify(access_token, ACCESS_SECRET);
    if (decoded.user_id !== user_id) throw new Error();

    return res.json(evaluate(message));
  } catch {
    return res.json({
      decision: "restricted",
      restriction_message: "Session expired. Please login again."
    });
  }
});

/* ---------------- START ---------------- */
app.listen(PORT, () =>
  console.log(`🚀 MCP running at http://localhost:${PORT}`)
);
